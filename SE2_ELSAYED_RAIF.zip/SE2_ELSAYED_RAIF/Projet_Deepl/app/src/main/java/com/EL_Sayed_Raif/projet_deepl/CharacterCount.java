package com.EL_Sayed_Raif.projet_deepl;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;

import org.json.JSONException;
import org.json.JSONObject;

public class CharacterCount extends AppCompatActivity {
    // Composants utilisés
    private EditText authKeyText;
    private TextView charCountText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Chargement de la vue associée à l'activité
        setContentView(R.layout.activity_character_count);
        //Initialisation de la bibliothèque AndroidNetworking
        AndroidNetworking.initialize(this);
        //Initialisation des variables
        initVariables();
    }
    public void initVariables(){
        //Référence au champ de saisie pour la clé d'authentification
        authKeyText = findViewById(R.id.keyEditText);
        //Référence au champ de texte pour le compte de caractères
        charCountText = findViewById(R.id.charCountText);
    }

    public void getCharCount(View view) {
        // Initialisation de l'objet AndroidNetworking avec l'URL de l'API d'utilisation de DeepL
        AndroidNetworking.get("https://api-free.deepl.com/v2/usage")
                // Ajout de l'en-tête avec la clé d'autorisation DeepL
                .addHeaders("Authorization","DeepL-Auth-Key "+ authKeyText.getText().toString())
                // Construction de la requête
                .build()
                // Obtention de la réponse sous forme d'objet JSON et gestion avec l'écouteur donné
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Conversion de la réponse JSONObject en chaîne
                        String jsonStr = response.toString();
                        try {
                            // Création d'un nouvel objet JSON à partir de la chaîne
                            JSONObject jsonObj = new JSONObject(jsonStr);
                            // Obtention du nombre de caractères et de la limite à partir de l'objet JSON
                            String charCount = jsonObj.getString("character_count");
                            String charLimit = jsonObj.getString("character_limit");
                            charCountText.setText("Character Count: " + charCount +"/"+ charLimit);

                        } catch (JSONException e) {
                            // Impression de la trace de la pile en cas d'erreur JSONException
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                        // Affichage d'un message toast en cas d'échec de la requête
                        Toast.makeText(getApplicationContext(), "Impossible d'obtenir le nombre de caractères!", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}