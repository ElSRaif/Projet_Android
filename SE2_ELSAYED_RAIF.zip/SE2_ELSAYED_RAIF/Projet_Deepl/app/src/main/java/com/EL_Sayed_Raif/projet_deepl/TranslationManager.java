
package com.EL_Sayed_Raif.projet_deepl;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;

    // Cette classe est responsable de la gestion des traductions stockées dans les préférences partagées
    public class TranslationManager {
        // Nom du fichier de préférences partagées
        private static final String PREFS_NAME = "Translations";
        // Préfixe de clé pour stocker les traductions dans les préférences partagées
        private static final String KEY_PREFIX = "Translation_";
        // Nombre maximal de traductions
        private static final int MAX_TRANSLATIONS = 10;
        // Fichier de données partagées
        private SharedPreferences fichier_donnee;
        // Constructeur qui reçoit le contexte de l'application
        public TranslationManager(Context context) {
            fichier_donnee = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        }
        // Ajouter une traduction
        public void ajouter_une_traduction(String language, String text) {
            // Récupérer la taille actuelle des traductions stockées
            int currentSize = fichier_donnee.getAll().size();
            // Editeur pour modifier les données dans les préférences partagées
            SharedPreferences.Editor editor = fichier_donnee.edit();
            // Supprimer la plus ancienne traduction si nous avons atteint la taille maximale
            if (currentSize >= MAX_TRANSLATIONS) {
                Map<String, ?> allEntries = fichier_donnee.getAll();
                ArrayList<String> cles = new ArrayList<>(allEntries.keySet());
                Collections.sort(cles);
                editor.remove(cles.get(0));
            }
            // Ajouter la nouvelle traduction
            editor.putString(KEY_PREFIX + currentSize, language + "|" + text);
            editor.commit();
        }
        // Récupérer toutes les traductions
        public ArrayList<Translation> recuprer_traduction() {
            ArrayList<Translation> translations = new ArrayList<>();
            Map<String, ?> allEntries = fichier_donnee.getAll();
            ArrayList<String> cles = new ArrayList<>(allEntries.keySet());
            Collections.sort(cles, Collections.reverseOrder());
            // Boucle pour ajouter chaque traduction à la liste
            for (String key : cles) {
                String[] parts = ((String) allEntries.get(key)).split("\\|");
                translations.add(new Translation(parts[0], parts[1]));
            }
            return translations;
        }
// Classe représentant une traduction dans une langue donnée.
        public static class Translation implements Serializable {
            private String lang;   // Langue de la traduction
            private String text;   // Texte traduit
            // Constructeur pour initialiser les variables lang et text
            public Translation(String lang, String text) {
                this.lang = lang;
                this.text = text;
            }
            // Méthode pour obtenir la langue de la traduction
            public String getLang() {
                return lang;
            }
            // Méthode pour obtenir le texte traduit
            public String getText() {
                return text;
            }
        }
    }