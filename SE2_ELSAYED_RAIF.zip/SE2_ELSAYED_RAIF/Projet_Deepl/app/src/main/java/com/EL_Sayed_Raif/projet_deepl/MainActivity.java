package com.EL_Sayed_Raif.projet_deepl;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONArrayRequestListener;
import com.androidnetworking.interfaces.JSONObjectRequestListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    // Composants utilisés
    private EditText text_entrer, text_traduit;
    private Spinner language_choisi;

    // Liste des langues disponibles sur DeepL
    private ArrayList<Language> languages = new ArrayList<>();
    private String langue_selectionnee;

    // Gestionnaire de traduction pour sauvegarder les préférences
    private TranslationManager translationManager;
    private Spinner spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Initialisation des composants
        initialisation();
        // Initialisation d'AndroidNetworking
        AndroidNetworking.initialize(this);
        // Récupération de la liste des langues disponibles sur DeepL
        langues();
        // Instanciation du gestionnaire de traduction
        translationManager = new TranslationManager(getApplicationContext());
        History();
    }

    //Méthode d'initialisation des variables
    public void initialisation(){
        //Association des variables avec les éléments du layout
        text_entrer = findViewById(R.id.enterText); //Variable associée à la zone de texte de saisie
        text_traduit = findViewById(R.id.traduction); //Variable associée à la zone de texte de traduction
        language_choisi = findViewById(R.id.spinner3); //Variable associée au menu déroulant de sélection de la langue
        spinner = findViewById(R.id.spinner);
    }

    // Méthode pour obtenir la liste des langues
    public void langues() {
        // Appel de l'API Deep pour charger la liste des langues disponibles
        AndroidNetworking.get("https://api-free.deepl.com/v2/languages")
                .addHeaders("Authorization","DeepL-Auth-Key 6c3cec34-e521-c80e-f6c2-ff924debf1d9:fx")
                .build()
                .getAsJSONArray(new JSONArrayRequestListener() {
                    @Override
                    public void onResponse(JSONArray response) {
                    // Convertir la réponse JSONArray en chaîne de caractères
                        String jsonString = response.toString();
                    // Appeler la méthode Spinners avec la chaîne JSON
                        Spinners(jsonString);
                    }
                    @Override
                    public void onError(ANError anError) {
                       // Afficher un toast pour indiquer échec de la récupération des langues disponibles depuis l'API DeepL
                        Toast.makeText(getApplicationContext(),"site n'exixte pas",Toast.LENGTH_SHORT).show();
                    }
                });
    }

    //Méthode pour convertir un tableau de type langues en tableau de type chaîne
    public ArrayList<String> convertToString(ArrayList<Language> arr){
        ArrayList<String> result = new ArrayList<>();
        //Parcourir le tableau "arr" de type Language
        for (Language l : arr) {
        //Ajouter le nom de la langue (propriété "name") dans le tableau de résultats "result"
            result.add(l.getNom());
        }
       //Retourner le tableau de résultats "result"
        return result;
    }

    //Méthode pour ajouter les noms des langues à un spinner
    public void Spinners(String jsonString){
        try {
            // Créez un tableau JSON à partir de la chaîne reçue de l'API
            JSONArray jsonArray = new JSONArray(jsonString);
            // Parcourez le tableau JSON
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String language = jsonObject.getString("language");
                String name = jsonObject.getString("name");
                // Créez un objet "Language" pour chaque entrée du tableau JSON
                final Language languageObj = new Language(name,language);
                // Ajoutez l'objet "Language" à la liste "languages"
                languages.add(languageObj);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        // Récupérez les noms des langues
        ArrayList<String> langNames = convertToString(languages);
        // Ajoutez les noms des langues au spinner
        ArrayAdapter adapter= new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_spinner_item, langNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        language_choisi.setAdapter(adapter);
        language_choisi.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Enregistrez le nom de la langue sélectionnée par l'utilisateur
                langue_selectionnee = parent.getItemAtPosition(position).toString();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    //Cette méthode sélectionne la langue choisie dans la liste des langues disponibles
    public String ChoisirUneLangues(String selectedLang){
        String ID = "";
        // Boucle sur la liste de toutes les langues disponibles
        for(Language lang:languages){
            // Si le nom de la langue dans la liste correspond au nom de la langue choisie
            if(lang.getNom().equalsIgnoreCase(selectedLang)){
                // Récupérer le ID de la langue choisie
                ID = lang.getLanguage();
            }
        }
        // Retourne le ID de la langue choisie
        return ID;
    }

    //Cette méthode permet de traduire le texte entré en utilisant l'API DeepL
    public void Traduction(View view){
        if(!text_entrer.getText().toString().isEmpty()){
            // Récupération du texte à traduire
            String text_a_traduire = text_entrer.getText().toString();
            // Récupération du code de la langue sélectionnée
            String Langue_choisi = ChoisirUneLangues(langue_selectionnee);

            // Appel de l'API DeepL pour la traduction
            AndroidNetworking.post("https://api-free.deepl.com/v2/translate")
                    .addHeaders("Authorization","DeepL-Auth-Key 6c3cec34-e521-c80e-f6c2-ff924debf1d9:fx")
                    .addQueryParameter("text",text_a_traduire)
                    .addQueryParameter("target_lang",Langue_choisi)
                    .build()
                    .getAsJSONObject(new JSONObjectRequestListener() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                // Récupération du résultat de la traduction
                                String jsonString = response.toString();
                                JSONObject jsonObject = new JSONObject(jsonString);
                                JSONArray translationsArray = jsonObject.getJSONArray("translations");
                                JSONObject firstTranslation = translationsArray.getJSONObject(0);
                                String translatedTextStr = firstTranslation.getString("text");
                                // Affichage du résultat de la traduction
                                text_traduit.setText(translatedTextStr);
                                translationManager.ajouter_une_traduction(Langue_choisi,translatedTextStr);
                                History();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        @Override
                        public void onError(ANError anError) {
                            Toast.makeText(getApplicationContext(),"Pas de traduction disponible",Toast.LENGTH_SHORT).show();
                        }
                    });

        }else{
            Toast.makeText(this,"Please Enter text to translate",Toast.LENGTH_SHORT).show();
        }
    }

    // Fonction pour afficher les 10 dernières traductions effectuées
    public void History() {
        // Récupération de la liste des traductions à partir de l'objet TranslationManager
        ArrayList<TranslationManager.Translation> translations = translationManager.recuprer_traduction();
        // Création d'un ArrayAdapter en utilisant la liste de traductions et un layout de spinner par défaut
        ArrayList<String> translationsStr = new ArrayList<>();
        translationsStr.add("History");
        for (TranslationManager.Translation t : translations) {
            // Ajout de chaque traduction à la liste de chaînes de caractères pour l'affichage
            translationsStr.add(t.getLang() + " - " + t.getText());
        }
        // Création de l'ArrayAdapter en utilisant la liste de chaînes de caractères pour les traductions
        ArrayAdapter adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, translationsStr);
        // Définition du layout à utiliser lorsqu'une liste de choix apparaît
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Récupération de la spinner à partir de son ID
        // Application de l'ArrayAdapter à la spinner
        spinner.setAdapter(adapter);
    }
    //Fonction pour obtenir le nombre de caractères.
    public void onClickCharCount(View view){
        //Création d'un objet Intent pour ouvrir une nouvelle activité
        Intent nextAct = new Intent(this,CharacterCount.class);
        //Lancement de la nouvelle activité
        startActivity(nextAct);
    }

}