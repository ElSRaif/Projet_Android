package com.EL_Sayed_Raif.projet_deepl;

public class Language {
    // Attribut pour stocker la langue
    private String language;
    // Attribut pour stocker le nom
    private String nom;
    // Constructeur pour initialiser les attributs
    public Language(String name, String language){
        this.language = language;
        this.nom = name;
    }
    // Redéfinition de la méthode toString pour retourner la valeur de la langue
    public String toString(){
        return language;
    }
    // Getter pour obtenir la valeur de la langue
    public String getLanguage(){
        return language;
    }
    // Getter pour obtenir la valeur du nom
    public String getNom(){
        return nom;
    }


}
